//
//  ViewController.swift
//  Week3Exo1
//
//  Created by Guest User on 30/05/2023.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    @IBAction func Hello() {
        performSegue(withIdentifier: "ShowLabel", sender: "Hello")
    }
    @IBAction func Bonjour() {
        performSegue(withIdentifier: "ShowLabel", sender: "Bonjour")
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        guard let identifier = segue.identifier else {
            return
        }
        switch (identifier, segue.destination, sender) {
        case("ShowLabel", let labelController as SecondController, let myString as String):
            labelController.text = myString
        default:
            break
        }
   
    }
    @IBAction func showAlert(_ sender: Any) {
        let alertController = UIAlertController(title: "Ceci est le titre", message: "Ceci est le message", preferredStyle: .alert)
        
        let okAction = UIAlertAction(title: "OK", style: .default) { (action) in
            alertController.dismiss(animated: true, completion: nil)
        }
        
        let secondAction = UIAlertAction(title: "Second", style: .default) { (action) in
                self.performSegue(withIdentifier: "ShowLabel", sender: "Alert")
        }
        
        alertController.addAction(okAction)
        alertController.addAction(secondAction)
        
        present(alertController, animated: true, completion: nil)
    }

}
class SecondController : UIViewController {
    @IBOutlet weak var textLabel: UILabel!
    var text: String?
    override func viewDidLoad() {
        super.viewDidLoad()
        textLabel.text = text
    }
    @IBAction func closeButtonAction() {
        dismiss(animated: true, completion: nil)
    }
    
    
}

