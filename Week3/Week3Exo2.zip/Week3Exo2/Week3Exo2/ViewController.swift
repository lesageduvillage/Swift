//
//  ViewController.swift
//  Week3Exo2
//
//  Created by Guest User on 30/05/2023.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    @IBAction func startButtonTapped(_ sender: Any) {
        let secondViewController = secondViewController()
        self.navigationController?.pushViewController(secondViewController, animated: false)
    }
}

class secondViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    @IBAction func continueButtonTapped(_ sender: Any) {
        let thirdViewController = thirdViewController()
        self.navigationController?.pushViewController(thirdViewController, animated: true)
    }
    @IBAction func backButtonTapped(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
}

class thirdViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    @IBAction func endButtonTapped(_ sender: Any) {
        self.navigationController?.popToRootViewController(animated: true)
    }

}
