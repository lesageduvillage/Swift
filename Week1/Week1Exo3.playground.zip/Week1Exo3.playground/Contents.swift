protocol LivingOrganism {
    var age: Int { get set }
    func eat()
    func askAge()
}

class Animal: LivingOrganism {
    var age: Int = 0
    func eat() {
        print("Cet animal mange")
    }
    func askAge(){
        return;
    }
}

class Féline: Animal {
    func meow()
    {
        print("Ce félin miaule.")
    }
}

class Dog: Animal {
}
class Cat: Féline {
}
class Puma: Féline {
}

class Human: LivingOrganism {
    var age: Int = 21
    func eat(){
        print("Cet humain mange")
    }
    func coffee(){
        print("Cet humain boit du café")
    }
    func askAge(){
        print(age);
    }
}

let chien = Dog()
let chat = Cat()
let puma = Puma()
let humain = Human()

chien.eat()
chat.askAge()
puma.meow()
humain.eat()
humain.coffee()
