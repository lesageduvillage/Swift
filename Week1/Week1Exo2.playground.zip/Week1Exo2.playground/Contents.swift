import Foundation
import PlaygroundSupport
PlaygroundPage.current.needsIndefiniteExecution = true

enum HTTPMethod: String {
    case get = "GET"
    case post = "POST"
    case delete = "DELETE"
}

enum HTTPServiceURL {
    case login
    case account(account_id: Int)
    case home(account_id: Int)
    case section(section_name: String, account_id: Int)
    
    var stringValue: String {
        switch self {
        case .login:
            return "/account/login"
        case .account(let account_id):
            return "/account/\(account_id)"
        case .home(let account_id):
            return "/home/\(account_id)"
        case .section(let section_name, let account_id):
            return "/section/\(section_name)/\(account_id)"
        }
    }
}
class HTTPService {
    func sendRequest (url: HTTPServiceURL, method:HTTPMethod) {
        let urlString = "https://example.com\(url.stringValue)"
        let url = URL(string: urlString)!
        var request = URLRequest(url: url)
        //Cette partie est mise en commentaire mais pourrait etre utilisé dans le cadre de l'exercice si les requetes HTTP étaient testées.
        //request.httpMethod = method.rawValue
        //request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        //request.addValue("application/json", forHTTPHeaderField: "Accept")
        //let task = URLSession.shared.dataTask(with: request) { data, response, error in
        // Traiter la réponse de la requête
        //}
        //task.resume()
    }
        // Méthode pour se connecter à un compte
        func login(login: String, password: String) {
            sendRequest(url: .login, method: .post)
        }
        // Méthode pour récupérer les informations d'un compte utilisateur
        func getAccountInfo(account_id: Int) {
            sendRequest(url: .account(account_id: account_id), method: .get)
        }
        // Méthode pour supprimer un compte utilisateur
        func deleteAccount(account_id: Int) {
            sendRequest(url: .account(account_id: account_id), method: .delete)
        }
        // Méthode pour accéder à la page d'accueil
        func getHomePage(account_id: Int) {
            sendRequest(url: .home(account_id: account_id), method: .get)
        }
        // Méthode pour accéder à une section
        func getSectionPage(section_name: String, account_id: Int) {
            sendRequest(url: .section(section_name: section_name, account_id: account_id), method: .get)
        }
    
}
// Exemple d'utilisation de la classe HTTPService
let httpService = HTTPService();
httpService.login(login: "john", password: "password123");
httpService.getAccountInfo(account_id: 1234);
httpService.deleteAccount(account_id: 1234);
httpService.getHomePage
