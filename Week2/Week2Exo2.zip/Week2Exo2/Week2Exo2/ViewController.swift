//
//  ViewController.swift
//  Week2Exo2
//
//  Created by Guest User on 04/04/2023.
//

import UIKit

class ViewController: UIViewController {
    var count = 0
    @IBOutlet weak var countLabel: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func plus() {
        count += 2
        countLabel.text = String(count);
    }
    
    @IBAction func minus() {
        count -= 1
        countLabel.text = String(count);
    }

}

